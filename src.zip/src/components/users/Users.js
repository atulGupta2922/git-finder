import { Component } from 'react';
import UserItem from './UserItem';

class Users extends Component {

    constructor() {;
        super();
        this.state = {
            users: [
                {
                    login: "user 1",
                    id: 1,
                    avatar_url: "httpsskdjfbvkjhgd",
                    html_url: "bkkzsjdfkj"
                },
                {
                    login: "user 2",
                    id: 2,
                    avatar_url: "httpsskdjfbvkjhgd",
                    html_url: "bkkzsjdfkj"
                },
                {
                    login: "user 3",
                    id: 3,
                    avatar_url: "httpsskdjfbvkjhgd",
                    html_url: "bkkzsjdfkj"
                }
            ]
        }
    }

    render() {
        return (
            <div className="container">
                {this.state.users.map( user => (
                    <UserItem userData={user} key={user.id} />
                ))}
            </div>
        )
    }
}

export default Users;